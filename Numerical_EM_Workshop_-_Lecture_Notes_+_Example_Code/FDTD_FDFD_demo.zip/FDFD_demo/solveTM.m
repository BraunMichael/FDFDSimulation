function [Ez, Hx, Hy, A, omega] = solveTM(L0, wvlen, xrange, yrange, eps_r, Jz, Npml)
%% Input Parameters
% L0: length unit (e.g., L0 = 1e-9 for nm)
% wvlen: wavelength in L0
% xrange: [xmin xmax], range of domain in x-direction including PML
% yrange: [ymin ymax], range of domain in y-direction including PML
% eps_r: Nx-by-Ny array of relative permittivity
% Mz: Nx-by-Ny array of magnetic current source density
% Npml: [Nx_pml Ny_pml], number of cells in x- and y-normal PML

%% Output Parameters
% Ez, Hx, Hy: Nx-by-Ny arrays of H- and E-field components
% dL: [dx dy] in L0
% A: system matrix of A x = b
% omega: angular frequency for given wvlen

%% Set up the domain parameters.
eps0 = 8.854e-12 * L0;  % vacuum permittivity in farad/L0
mu0 = pi * 4e-7 * L0;  % vacuum permeability in henry/L0
c0 = 1/sqrt(eps0*mu0);  % speed of light in vacuum in L0/sec

N = size(eps_r);  % [Nx Ny]
L = [diff(xrange) diff(yrange)];  % [Lx Ly]
dL = L./(N);  % [dx dy]

M = prod(N); 

omega = 2*pi*c0/wvlen;  % angular frequency in rad/sec

%% Deal with the s_factor
[Sxf, Sxb, Syf, Syb] = S_create(L0, wvlen, xrange, yrange, N, Npml); 

%% Set up the permittivity and permeability in the domain.
eps_z = eps0 * eps_r; 

% Reshape epsilon into 1D array 
vector_eps_z = reshape(eps_z, M, 1); 

% Setup the T_eps_z matrix
T_eps_z = spdiags(vector_eps_z, 0, M, M); 

%% Construct derivate matrices
Dyb = createDws('y', 'b', dL, N); 
Dxb = createDws('x', 'b', dL, N); 
Dxf = createDws('x', 'f', dL, N); 
Dyf = createDws('y', 'f', dL, N); 

%% Reshape Mz into a vector
jz = reshape(Jz, M, 1); 

%% Construct A matrix and b vector
A = Sxb*Dxb * mu0^-1 * Sxf*Dxf + Syb*Dyb * mu0^-1 * Syf*Dyf + omega^2*T_eps_z; 

b = 1i * omega * jz; 

%% Solve the equation.
if all(b==0)
	ez = zeros(size(b));
else
	ez = A\b;
end
Ez = reshape(ez, N);

%% Reconstruct the Hx and Hy fields
hx = -1/(1i*omega) * mu0^-1 * Syf*Dyf * ez; 
hy = 1/(1i*omega) * mu0^-1 * Sxf*Dxf * ez; 

Hx = reshape(hx, N); 
Hy = reshape(hy, N); 

end
