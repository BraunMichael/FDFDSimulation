clear all; close all; clc;

%% Set up the domain parameters.
% L0 = 1e-6;  % length unit: nm
L0 = 1e-6;  % length unit: nm

xrange = [-2 2];  % x boundaries in L0
yrange = [-2 2];  % y boundaries in L0
N = [200 200];  % [Nx Ny]

wvlen0 = 1.55

hx = diff(xrange) / (N(1)); 
hy = diff(yrange) / (N(2)); 

%% Number of PMLs
% Npml = [0 0]; % <---- Periodic boundary conditions
Npml = [10 10];  % <------ Absorbing boundary conditions

%%
eps0 = 8.854e-12 * L0;  % vacuum permittivity in farad/L0
mu0 = pi * 4e-7 * L0;  % vacuum permeability in henry/L0
c0 = 1/sqrt(eps0*mu0);  % speed of light in vacuum in L0/sec

omega0 = 2*pi*c0 / wvlen0; 

%% Set up the permittivity.
eps_space = ones(N);

%% Dielectric scatterer
eps_scat = 4; 

scat_loc = [0.2, 0.8 -0.1, 0.4]; 

within_scat = @(x, y) x > scat_loc(1) & x < scat_loc(2) & y > scat_loc(3) & y < scat_loc(4); 

% eps_space = assign_val(eps_space, xrange, yrange, within_scat, eps_scat);

%% Visualize permittivity distribution
figure; 
visabs(eps_space, xrange, yrange); 
title('Permittivity distribution'); 
xlabel('x (\mum)'); ylabel('y (\mum)'); 
pause

%% Set up the source
%%%%%%%%%%%%%%%%%% Point source %%%%%%%%%%%%%%%%
Jz0 = zeros(N);

src_x = 0; 
src_y = 0; 

src_ind_x = round((src_x-xrange(1)) / diff(xrange) * N(1)) + 1; 
src_ind_y = round((src_y-yrange(1)) / diff(yrange) * N(2)) + 1; 

Jz0(src_ind_x, src_ind_y) = 1i; 

%% Probe location
probe_loc = [1.5 1.5]; 

probe_ind_x = round((probe_loc(1)-xrange(1)) / diff(xrange) * N(1)) + 1; 
probe_ind_y = round((probe_loc(2)-yrange(1)) / diff(yrange) * N(2)) + 1; 


%% Solve for field distributions
[Ez, Hx, Hy, A, omega] = solveTM(L0, wvlen0, xrange, yrange, eps_space, Jz0, Npml); 

%%
figure; 
visabs(Ez, xrange, yrange); 
title('Ez'); xlabel('x (\mum)'); ylabel('y (\mum)'); 

%%

%% Make a movie out of the fields
figure; 
moviereal(Ez, xrange, yrange, 3, 30)


