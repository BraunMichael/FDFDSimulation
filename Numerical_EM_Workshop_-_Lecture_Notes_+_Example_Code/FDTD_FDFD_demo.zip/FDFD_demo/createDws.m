function Dws = createDws(w, s, dL, N)
% w: one of 'x', 'y', 'z'
% s: one of 'f' and 'b'
% dL: [dx dy dz] for 3D; [dx dy] for 2D
% N: [Nx Ny Nz] for 3D; [Nx Ny] for 2D

dw = dL('xyz' == w);  % one of dx, dy, dz
sign = diff('bf' == s);  % +1 for s=='f'; -1 for s=='b'
M = prod(N);  % total number of cells in domain


% Dws = zeros(M);  % Initialize Dws into the appropriate square matrix

% Compute Nx, Ny, and Nz
Nx = N(1); 
Ny = N(2); 
if (length(N) == 3)
    Nz = N(3); 
else
    Nz = 1; 
end

%%

Ix = speye(Nx); 
Iy = speye(Ny); 



%%
switch w
    case 'x'
        if s == 'f'
            dxf = -Ix + circshift(Ix, [0 1]); 
            Dws = 1/dL(1) * kron(Iy, dxf); 
        else
            dxb = Ix - circshift(Ix, [0 -1]); 
            Dws = 1/dL(1) * kron(Iy, dxb); 
        end
        
        
    case 'y'
        if s == 'f'
            dyf = -Iy + circshift(Iy, [0 1]); 
            Dws = 1/dL(2) * kron(dyf, Ix); 
        else
            dyb = Iy - circshift(Iy, [0 -1]); 
            Dws = 1/dL(2) * kron(dyb, Ix); 
        end
end

%%

end

