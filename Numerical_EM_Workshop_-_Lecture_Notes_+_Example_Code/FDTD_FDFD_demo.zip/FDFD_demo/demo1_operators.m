clear all; close all; clc; 

%% Specify some random domain parameters
N = [7 4]; % N = [Nx, Ny]
dL = [1 1]; % dL = [dx, dy]

%% Differential operators
Dxf = createDws('x', 'f', dL, N); 
Dxb = createDws('x', 'b', dL, N); 
Dyf = createDws('y', 'f', dL, N); 
Dyb = createDws('y', 'b', dL, N); 


%% Visualize differential operators 
figure; 
subplot(2, 2, 1); imagesc(Dxf); title('D_x^f'); axis square; colorbar; 
subplot(2, 2, 2); imagesc(Dxb); title('D_x^b'); axis square; colorbar; 
subplot(2, 2, 3); imagesc(Dyf); title('D_y^f'); axis square; colorbar; 
subplot(2, 2, 4); imagesc(Dyb); title('D_y^b'); axis square; colorbar; 
colormap 'b2r'
caxis([-1 1])


%% Create and visualize the A operator
A = Dxb*Dxf + Dyb*Dyf + speye(prod(N), prod(N)); 

figure; 
imagesc(A); 
title('A operator'); axis square; colorbar; 
% colormap hot; 
colormap 'b2r'
caxis([-2 2])