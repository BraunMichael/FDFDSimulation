clear all; close all; clc;

%% Set up the domain parameters.
% L0 = 1e-6;  % length unit: nm
L0 = 1e-6;  % length unit: nm

xrange = [0 7];  % x boundaries in L0
yrange = [0 7];  % y boundaries in L0
N = [280 280];  % [Nx Ny]
Npml = [15 15];  % [Nx_pml, Ny_pml]

% % % % Resonant wavelength
% wvlen0 = 1.5081

% % % % Non-resonant wavelength
wvlen0 = 1.5091

hx = diff(xrange) / (N(1)); 
hy = diff(yrange) / (N(2)); 

src_max1 = 1i;
src_max2 = 1; 

%%
eps0 = 8.854e-12 * L0;  % vacuum permittivity in farad/L0
mu0 = pi * 4e-7 * L0;  % vacuum permeability in henry/L0
c0 = 1/sqrt(eps0*mu0);  % speed of light in vacuum in L0/sec

omega0 = 2*pi*c0 / wvlen0; 

%% Set up the permittivity.
eps_wg = 12; 
eps_ring = 12 - 1i*3e-4; 

eps_clad = 1; 

eps_space = eps_clad*ones(N);



%% Silicon waveguide 
a = 0.11251; 
wg_c = 1.049; 

within_wg = @(x, y) abs((y - wg_c)) < a; 

eps_space = assign_val(eps_space, xrange, yrange, within_wg, eps_wg);

%% Disc
ring_c = [3.5000, 3.5000]; 
ring_w = 0.200; 


ring_r1 = 2.1; 

ring_r2 = ring_r1 - ring_w; 


r = @(x, y) sqrt((x - ring_c(1)).^2 + (y - ring_c(2)).^2); 
within_ring_r1 = @(x, y) abs(r(x, y)) < ring_r1; 
within_ring_r2 = @(x, y) abs(r(x, y)) < ring_r2; 

eps_space = assign_val(eps_space, xrange, yrange, within_ring_r1, eps_ring);
eps_space = assign_val(eps_space, xrange, yrange, within_ring_r2, 1);

visabs(eps_space, xrange, yrange);
pause; 

%% Set up the source
%%%%%%%%%%%%%%%%%% Single mode source %%%%%%%%%%%%%%%%
Jz0 = zeros(N);
pts = 40; 
m = 0; 

[beta1, ky1, alpha1, Ez1_src, A1, ~] = beta_sym_TM(L0, wvlen0, a, eps_clad, eps_ring, m, hy, pts); 

src_x = 0.999; 
src_y = wg_c; 

src_ind_x = round((src_x-xrange(1)) / diff(xrange) * N(1)) + 1; 
src_ind_y = round((src_y-yrange(1)) / diff(yrange) * N(2)) + 1; 

Jz0(src_ind_x, src_ind_y + (-pts-1:pts-1)) = 1i*Ez1_src; 

%% Visualize permittivity distribution
figure; visabs(eps_space, xrange, yrange); 
title('Permittivity distribution'); xlabel('x (\mum)'); ylabel('y (\mum)'); 

%% Probe location
probe_loc = [6.001, wg_c]; 

probe_ind_x = round((probe_loc(1)-xrange(1)) / diff(xrange) * N(1)) + 1; 
probe_ind_y = round((probe_loc(2)-yrange(1)) / diff(yrange) * N(2)) + 1; 


%% Solve for field distributions
[Ez, Hx, Hy, A, omega] = solveTM(L0, wvlen0, xrange, yrange, eps_space, Jz0, Npml); 

%%
norm1 = Ez1_src(pts + 1) / max(abs(Ez(101, src_ind_y)))

%%
figure; 
visreal(Ez, xrange, yrange); 
title('Ez'); xlabel('x (\mum)'); ylabel('y (\mum)'); 

%%
transmission = abs(Ez(probe_ind_x, probe_ind_y) / Ez(src_ind_x, src_ind_y))

%% Make a movie out of the fields
figure; 
moviereal(Ez, xrange, yrange, 3, 20)


