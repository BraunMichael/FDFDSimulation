function [Ez, Hx, Hy, Ez_probe] = FDTD_tfsf(L0, wvlen, xrange, yrange, tfsf_loc, phi, probe_loc, N, Npml, eps_r)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%% Set up numerical parameters
eps0 = 8.854e-12 * L0;  % vacuum permittivity in farad/L0
mu0 = pi * 4e-7 * L0;  % vacuum permeability in henry/L0
c0 = 1/sqrt(eps0*mu0);  % speed of light in vacuum in L0/sec

%% Compute simulation space size and step size
M = length(eps_r(:, 1))
P = length(eps_r(1, :))
Nsize = [M, P]; 

%% Initialize the computational space
x_vec = linspace(xrange(1), xrange(2), M); 
y_vec = linspace(yrange(1), yrange(2), P); 

%% Create discretization steps
courant = sqrt(2); 
hx = x_vec(2) - x_vec(1); 
hy = y_vec(2) - y_vec(1); 
ht = 1/c0 * 1/sqrt(hx^-2 + hy^-2) / courant; 

%% Initializing fields
Ez_scat = zeros(M, P); 
Hy_scat = zeros(M, P); 
Hx_scat = zeros(M, P); 

Ez_tot = zeros(M, P); 
Hy_tot = zeros(M, P); 
Hx_tot = zeros(M, P); 

Ez = zeros(M, P); 
Hy = zeros(M, P); 
Hx = zeros(M, P); 

% Jz = zeros(1, N); 
Ez_probe = zeros(1, N); 

%% Find TFSF indices
i0 = floor((tfsf_loc(1)-xrange(1)) ./ diff(xrange) .* M) + 1
i1 = floor((tfsf_loc(2)-xrange(1)) ./ diff(xrange) .* M) + 1
j0 = floor((tfsf_loc(3)-yrange(1)) ./ diff(yrange) .* P) + 1
j1 = floor((tfsf_loc(4)-yrange(1)) ./ diff(yrange) .* P) + 1



%% Initialize incident field arrays
Hx_inc_top = zeros(i1-i0+1, 1); 
Hx_inc_bottom = zeros(i1-i0+1, 1); 

Hy_inc_left = zeros(1, j1-j0+1); 
Hy_inc_right = zeros(1, j1-j0+1); 

Ez_inc_top = zeros(i1-i0+1, 1); 
Ez_inc_bottom = zeros(i1-i0+1, 1); 

Ez_inc_left = zeros(1, j1-j0+1); 
Ez_inc_right = zeros(1, j1-j0+1); 


%% Initialize psi matrices
psi_Ez_x = zeros(M, P); 
psi_Ez_y = zeros(M, P); 
psi_Hx_y = zeros(M, P); 
psi_Hy_x = zeros(M, P); 

%% Specify incident angle and numerical dispersion constants
% phi = 320 * pi/180; 


%% Initialize 1D incident field look-up array
E_inc_1D = zeros(1, i1-i0 + j1-j0 + 4); 
H_inc_1D = zeros(1, i1-i0 + j1-j0 + 4); 


if (phi >= 0 && phi <= pi/2)
    % r_comp for Ez 
    r_comp_bottom_Ez = [0 : i1-i0; zeros(1, i1-i0+1)]; 
    r_comp_top_Ez = [0 : i1-i0; (j1-j0) * ones(1, i1-i0+1)]; 
    r_comp_left_Ez = [zeros(1, j1-j0+1); 0 : j1-j0]; 
    r_comp_right_Ez = [(i1-i0) * ones(1, j1-j0+1); 0:j1-j0]; 

    % r_comp for Hx and Hy
    r_comp_bottom_Hx = [0 : i1-i0; -0.5 * ones(1, i1-i0+1)]; 
    r_comp_top_Hx = [0 : i1-i0; (j1-j0+0.5) * ones(1, i1-i0+1)]; 

    r_comp_left_Hy = [-0.5 * ones(1, j1-j0+1); 0 : j1-j0]; 
    r_comp_right_Hy = [(i1-i0+0.5) * ones(1, j1-j0+1); 0:j1-j0]; 
    
elseif (phi > pi/2 && phi <= pi)
    % r_comp for Ez 
    r_comp_bottom_Ez = [i0-i1 : 0; zeros(1, i1-i0+1)]; 
    r_comp_top_Ez = [i0-i1 : 0; (j1-j0) * ones(1, i1-i0+1)]; 
    r_comp_left_Ez = [(i0-i1) * ones(1, j1-j0+1); 0 : j1-j0]; 
    r_comp_right_Ez = [zeros(1, j1-j0+1); 0:j1-j0]; 

    % r_comp for Hx and Hy
    r_comp_bottom_Hx = [i0-i1 : 0; -0.5 * ones(1, i1-i0+1)]; 
    r_comp_top_Hx = [i0-i1 : 0; (j1-j0+0.5) * ones(1, i1-i0+1)]; 

    r_comp_left_Hy = [(i0-i1-0.5) * ones(1, j1-j0+1); 0 : j1-j0]; 
    r_comp_right_Hy = [0.5 * ones(1, j1-j0+1); 0:j1-j0]; 
    
elseif (phi > pi && phi <= 3*pi/2)
    % r_comp for Ez 
    r_comp_bottom_Ez = [i0-i1 : 0; (j0-j1) * ones(1, i1-i0+1)]; 
    r_comp_top_Ez = [i0-i1 : 0; zeros(1, i1-i0+1)]; 
    r_comp_left_Ez = [(i0-i1) * ones(1, j1-j0+1); j0-j1 : 0]; 
    r_comp_right_Ez = [zeros(1, j1-j0+1); j0-j1 : 0]; 

    % r_comp for Hx and Hy
    r_comp_bottom_Hx = [i0-i1 : 0; (j0-j1-0.5) * ones(1, i1-i0+1)]; 
    r_comp_top_Hx = [i0-i1 : 0; 0.5*ones(1, i1-i0+1)]; 

    r_comp_left_Hy = [(i0-i1-0.5) * ones(1, j1-j0+1); j0-j1 : 0]; 
    r_comp_right_Hy = [0.5*ones(1, j1-j0+1); j0-j1 : 0]; 
    
else
    % r_comp for Ez 
    r_comp_bottom_Ez = [0 : i1-i0; (j0-j1) * ones(1, i1-i0+1)]; 
    r_comp_top_Ez = [0 : i1-i0; zeros(1, i1-i0+1)]; 
    r_comp_left_Ez = [zeros(1, j1-j0+1); j0-j1 : 0]; 
    r_comp_right_Ez = [(i1-i0) * ones(1, j1-j0+1); j0-j1 : 0]; 

    % r_comp for Hx and Hy
    r_comp_bottom_Hx = [0 : i1-i0; (j0-j1-0.5) * ones(1, i1-i0+1)]; 
    r_comp_top_Hx = [0 : i1-i0; 0.5 * ones(1, i1-i0+1)]; 

    r_comp_left_Hy = [-0.5 * ones(1, j1-j0+1); j0-j1 : 0]; 
    r_comp_right_Hy = [(i1-i0+0.5) * ones(1, j1-j0+1); j0-j1 : 0]; 
end
    



% Generate a projection table for incident waves
k_hat = [cos(phi); sin(phi)]; 

d_bottom_Ez = dot(r_comp_bottom_Ez, kron(k_hat, ones(1, i1-i0+1))); 
d_top_Ez = dot(r_comp_top_Ez, kron(k_hat, ones(1, i1-i0+1))); 
d_left_Ez = dot(r_comp_left_Ez, kron(k_hat, ones(1, j1-j0+1))); 
d_right_Ez = dot(r_comp_right_Ez, kron(k_hat, ones(1, j1-j0+1))); 

dp_bottom_Ez = d_bottom_Ez - fix(d_bottom_Ez); 
dp_top_Ez = d_top_Ez - fix(d_top_Ez); 
dp_left_Ez = d_left_Ez - fix(d_left_Ez); 
dp_right_Ez = d_right_Ez - fix(d_right_Ez); 


% d_bottom_Hx = dot(r_comp_bottom_Hx, kron(k_hat, ones(1, i1-i0+1))) - 0.5; 
% d_top_Hx = dot(r_comp_top_Hx, kron(k_hat, ones(1, i1-i0+1))) - 0.5; 
% d_left_Hy = dot(r_comp_left_Hy, kron(k_hat, ones(1, j1-j0+1))) - 0.5; 
% d_right_Hy = dot(r_comp_right_Hy, kron(k_hat, ones(1, j1-j0+1))) - 0.5; 

d_bottom_Hx = dot(r_comp_bottom_Hx, kron(k_hat, ones(1, i1-i0+1))); 
d_top_Hx = dot(r_comp_top_Hx, kron(k_hat, ones(1, i1-i0+1))); 
d_left_Hy = dot(r_comp_left_Hy, kron(k_hat, ones(1, j1-j0+1))); 
d_right_Hy = dot(r_comp_right_Hy, kron(k_hat, ones(1, j1-j0+1))); 

% dp_bottom_Hx = d_bottom_Hx - fix(d_bottom_Hx) - 0.5; 
% dp_top_Hx = d_top_Hx - fix(d_top_Hx) - 0.5; 
% dp_left_Hy = d_left_Hy - fix(d_left_Hy) - 0.5; 
% dp_right_Hy = d_right_Hy - fix(d_right_Hy) - 0.5; 

dp_bottom_Hx = d_bottom_Hx - fix(d_bottom_Hx); 
dp_top_Hx = d_top_Hx - fix(d_top_Hx); 
dp_left_Hy = d_left_Hy - fix(d_left_Hy); 
dp_right_Hy = d_right_Hy - fix(d_right_Hy); 

m0 = 2; 

%% Calculate the numerically dispersed phase velocity
vp_0 = c0 / num_disp(L0, 0, wvlen, hx, ht); 
vp_phi = c0 / num_disp(L0, phi, wvlen, hx, ht); 

num_disp_factor = vp_0 / vp_phi
vp_inc = vp_0 / num_disp_factor 
% vp_inc = vp_0; 


%% Specify the location of the source
% src_index_x = floor((src_loc(1)-xrange(1)) ./ diff(xrange) .* M) + 1
% src_index_y = floor((src_loc(2:end) - yrange(1)) ./ diff(yrange) .* P) + 1

pulse_width = 10e-15; 
% pulse_width = 20e-15; 

%% Specify the location of the probe
% [~, probe_index_x] = min(abs(x_vec - probe_loc(1))); 
% [~, probe_index_y] = min(abs(y_vec - probe_loc(2))); 

probe_index_x = round((probe_loc(1)-xrange(1)) ./ diff(xrange) .* M) + 1;
probe_index_y = round((probe_loc(2)-yrange(1)) ./ diff(yrange) .* P) + 1;


%% Convert things back into meters units
hx = hx*L0; 
hy = hy*L0; 
c0 = c0*L0; 
vp_inc = vp_inc*L0; 
wvlen = wvlen * L0; 

% ht = 1/c0 * 1/sqrt(hx^-2 + hy^-2); 
eps0 = eps0/L0; 
mu0 = mu0/L0; 

%% Update permittivity 
eps = eps_r * eps0; 

%% Construct sigma matrices for E
sigma_x_vec_E = generate_sigma(L0, xrange, 'f', Nsize(1), Npml(1)); 
sigma_y_vec_E = generate_sigma(L0, yrange, 'f', Nsize(2), Npml(2)); 

[sigma_x_E, sigma_y_E] = meshgrid(sigma_x_vec_E, sigma_y_vec_E); 
sigma_x_E = transpose(sigma_x_E); 
sigma_y_E = transpose(sigma_y_E); 

%% Construct sigma matrices for H
sigma_x_vec_H = generate_sigma(L0, xrange, 'f', Nsize(1), Npml(1)); 
sigma_y_vec_H = generate_sigma(L0, yrange, 'f', Nsize(2), Npml(2)); 

[sigma_x_H, sigma_y_H] = meshgrid(sigma_x_vec_H, sigma_y_vec_H); 
sigma_x_H = transpose(sigma_x_H); 
sigma_y_H = transpose(sigma_y_H); 

%% Compute indicies that are in CPML
pml_index_x = [2:Npml(1)+1, M-Npml(1)+1:M]; 
pml_index_y = [2:Npml(2)+1, P-Npml(2)+1:P]; 

%% Compute a_x, b_x, a_y, b_y
b_x_E = exp(-sigma_x_E / eps0 * ht); 
a_x_E = b_x_E - 1; 
b_y_E = exp(-sigma_y_E / eps0 * ht); 
a_y_E = b_y_E - 1; 

b_x_H = exp(-sigma_x_H / eps0 * ht); 
a_x_H = b_x_H - 1; 
b_y_H = exp(-sigma_y_H / eps0 * ht); 
a_y_H = b_y_H - 1; 

ht./eps(2:M-1, 2:P-1)/hx; 


%% FDTD full algorithm
for n = 1:N
    if(mod(n, 2000) == 0)
        n
    end
    
    %% Update psi_Ez_x and psi_Ez_y
%     psi_Ez_x(pml_index_x, 2:P-1) = b_x_E(pml_index_x, 2:P-1).* psi_Ez_x(pml_index_x, 2:P-1) + ... 
%                                     + a_x_E(pml_index_x, 2:P-1) .* (Hy(pml_index_x, 2:P-1) - Hy(pml_index_x-1, 2:P-1)) / hx; 
%     psi_Ez_y(2:M-1, pml_index_y) = b_y_E(2:M-1, pml_index_y) .* psi_Ez_y(2:M-1, pml_index_y) + ...
%                                     + a_y_E(2:M-1, pml_index_y) .* (Hx(2:M-1, pml_index_y) - Hx(2:M-1, pml_index_y-1)) / hy; 

    psi_Ez_x(pml_index_x, 1:P) = b_x_E(pml_index_x, 1:P).* psi_Ez_x(pml_index_x, 1:P) + ... 
                                    + a_x_E(pml_index_x, 1:P) .* (Hy_scat(pml_index_x, 1:P) - Hy_scat(pml_index_x-1, 1:P)) / hx; 
    psi_Ez_y(1:M, pml_index_y) = b_y_E(1:M, pml_index_y) .* psi_Ez_y(1:M, pml_index_y) + ...
                                    + a_y_E(1:M, pml_index_y) .* (Hx_scat(1:M, pml_index_y) - Hx_scat(1:M, pml_index_y-1)) / hy; 
                                
    %% Compute the current source
%     Jz = 1e9*exp(-(((n-1/2) * ht - 4*pulse_width)/pulse_width).^2) .* sin((2*pi*c0/wvlen) * (n-1/2)*ht); 

    Jz = 1e9*sin((2*pi*c0/wvlen) * (n-1/2)*ht); 
    
    
%     Jz = 1e11*sin((2*pi*c0/wvlen) * (n-1/2)*ht); 
%     Jz = 4.1e13*Gauss_env .* sin((2*pi*c0/wvlen) * (n-1/2)*ht + Gauss_phase); 
    

    %% Auxilary 1D update equation for the incident field
    E_inc_1D(1) = Jz; 
    
    % Store value for BC
    E_temp2 = E_inc_1D(end-1); 
    
    % Update E_inc_1D array
    E_inc_1D(2:end-1) = E_inc_1D(2:end-1) + ht / (eps0 * num_disp_factor * hx) * (H_inc_1D(2:end-1) - H_inc_1D(1:end-2)); 

    % BC for E_inc_1D
    E_inc_1D(end) = E_temp2 + (vp_inc*ht - hx)/(vp_inc*ht + hx) * (E_inc_1D(end-1) - E_inc_1D(end)); 
    
    % Update H_inc_1D
    H_inc_1D(1:end-1) = H_inc_1D(1:end-1) + ht / (mu0 * num_disp_factor * hx) * (E_inc_1D(2:end) - E_inc_1D(1:end-1)); 
    


    %% Calculate the incident field array via projection and interpolation
    %% Ez field
    Ez_inc_left = (1-dp_left_Ez) .* E_inc_1D(m0 + fix(d_left_Ez)) + dp_left_Ez .* E_inc_1D(m0 + fix(d_left_Ez)+1); 
    Ez_inc_right = (1-dp_right_Ez) .* E_inc_1D(m0 + fix(d_right_Ez)) + dp_right_Ez .* E_inc_1D(m0 + fix(d_right_Ez)+1); 
    Ez_inc_top = (1-dp_top_Ez) .* E_inc_1D(m0 + fix(d_top_Ez)) + dp_top_Ez .* E_inc_1D(m0 + fix(d_top_Ez)+1); 
    Ez_inc_bottom = (1-dp_bottom_Ez) .* E_inc_1D(m0 + fix(d_bottom_Ez)) + dp_bottom_Ez .* E_inc_1D(m0 + fix(d_bottom_Ez)+1); 
    
    Ez_inc_top = transpose(Ez_inc_top); 
    Ez_inc_bottom = transpose(Ez_inc_bottom); 
    
    %% H fields
    Hy_inc_left = ((1-dp_left_Hy) .* H_inc_1D(m0 + fix(d_left_Hy)) + dp_left_Hy .* H_inc_1D(m0 + fix(d_left_Hy)+1)) * (cos(phi)); 
    Hy_inc_right = ((1-dp_right_Hy) .* H_inc_1D(m0 + fix(d_right_Hy)) + dp_right_Hy .* H_inc_1D(m0 + fix(d_right_Hy)+1)) * (cos(phi)); 
    Hx_inc_top = ((1-dp_top_Hx) .* H_inc_1D(m0 + fix(d_top_Hx)) + dp_top_Hx .* H_inc_1D(m0 + fix(d_top_Hx)+1)) * (-sin(phi)); 
    Hx_inc_bottom = ((1-dp_bottom_Hx) .* H_inc_1D(m0 + fix(d_bottom_Hx)) + dp_bottom_Hx .* H_inc_1D(m0 + fix(d_bottom_Hx)+1)) * (-sin(phi)); 
    
    Hx_inc_top = transpose(Hx_inc_top); 
    Hx_inc_bottom = transpose(Hx_inc_bottom); 
    
    %% Update Ez for the linear region
    % 
    % Scatter region: Normal update
    Ez_scat([2:(i0-1) (i1+1):M], 2:P) = Ez_scat([2:(i0-1) (i1+1):M], 2:P) + ht./eps([2:(i0-1) (i1+1):M], 2:P) .* ((Hy_scat([2:(i0-1) (i1+1):M], 2:P) - Hy_scat([2:(i0-1) (i1+1):M]-1, 2:P))./hx - (Hx_scat([2:(i0-1) (i1+1):M], 2:P) - Hx_scat([2:(i0-1) (i1+1):M], 1:P-1))./hy) + ...
                    + ht./eps([2:(i0-1) (i1+1):M], 2:P) .* (psi_Ez_x([2:(i0-1) (i1+1):M], 2:P) - psi_Ez_y([2:(i0-1) (i1+1):M], 2:P)); 
    
    Ez_scat(i0:i1, [2:(j0-1) (j1+1):P]) = Ez_scat(i0:i1, [2:(j0-1) (j1+1):P]) + ht./eps(i0:i1, [2:(j0-1) (j1+1):P]) .* ((Hy_scat(i0:i1, [2:(j0-1) (j1+1):P]) - Hy_scat([i0:i1]-1, [2:(j0-1) (j1+1):P]))./hx - (Hx_scat(i0:i1, [2:(j0-1) (j1+1):P]) - Hx_scat(i0:i1, [2:(j0-1) (j1+1):P]-1))./hy) + ...
                    + ht./eps(i0:i1, [2:(j0-1) (j1+1):P]) .* (psi_Ez_x(i0:i1, [2:(j0-1) (j1+1):P]) - psi_Ez_y(i0:i1, [2:(j0-1) (j1+1):P])); 

    % Total region: Normal update without PML
    Ez_tot((i0+1):(i1-1), (j0+1):(j1-1)) = Ez_tot((i0+1):(i1-1), (j0+1):(j1-1)) + ... 
                                    + ht./eps((i0+1):(i1-1), (j0+1):(j1-1)) .* ((Hy_tot((i0+1):(i1-1), (j0+1):(j1-1)) - Hy_tot([(i0+1):(i1-1)]-1, (j0+1):(j1-1)))./hx - (Hx_tot((i0+1):(i1-1), (j0+1):(j1-1)) - Hx_tot((i0+1):(i1-1), [(j0+1):(j1-1)]-1))./hy); 
    

    %% The corners are separately updated
    % Non-corners
    Ez_tot(i0, j0+1:j1-1) = Ez_tot(i0, j0+1:j1-1) + ... 
                                    + ht./eps(i0, j0+1:j1-1) .* ((Hy_tot(i0, j0+1:j1-1) - Hy_scat(i0-1, j0+1:j1-1))./hx - (Hx_tot(i0, j0+1:j1-1) - Hx_tot(i0, j0:j1-2))./hy) + ...
                                    - ht./eps(i0, j0+1:j1-1)/hx .* Hy_inc_left(2:end-1); 
                                
    Ez_tot(i1, j0+1:j1-1) = Ez_tot(i1, j0+1:j1-1) + ... 
                                    + ht./eps(i1, j0+1:j1-1) .* ((Hy_scat(i1, j0+1:j1-1) - Hy_tot(i1-1, j0+1:j1-1))./hx - (Hx_tot(i1, j0+1:j1-1) - Hx_tot(i1, j0:j1-2))./hy) + ...
                                    + ht./eps(i1, j0+1:j1-1)/hx .* Hy_inc_right(2:end-1); 
                                
    Ez_tot(i0+1:i1-1, j0) = Ez_tot(i0+1:i1-1, j0) + ... 
                                    + ht./eps(i0+1:i1-1, j0) .* ((Hy_tot(i0+1:i1-1, j0) - Hy_tot(i0:i1-2, j0))./hx - (Hx_tot(i0+1:i1-1, j0) - Hx_scat(i0+1:i1-1, j0-1))./hy) + ...
                                    + ht./eps(i0+1:i1-1, j0)/hy .* Hx_inc_bottom(2:end-1);    
                                
    Ez_tot(i0+1:i1-1, j1) = Ez_tot(i0+1:i1-1, j1) + ... 
                                    + ht./eps(i0+1:i1-1, j1) .* ((Hy_tot(i0+1:i1-1, j1) - Hy_tot(i0:i1-2, j1))./hx - (Hx_scat(i0+1:i1-1, j1) - Hx_tot(i0+1:i1-1, j1-1))./hy) + ...
                                    - ht./eps(i0+1:i1-1, j1)/hy .* Hx_inc_top(2:end-1); 
    
    % Corners
    Ez_tot(i0, j0) = Ez_tot(i0, j0) + ...
                        + ht./eps(i0, j0) .* ((Hy_tot(i0, j0) - Hy_scat(i0-1, j0))./hx - (Hx_tot(i0, j0) - Hx_scat(i0, j0-1))./hy) + ...
                        + ht./eps(i0, j0) .* (-Hy_inc_left(1) / hx + Hx_inc_bottom(1) / hy); 
    
    Ez_tot(i0, j1) = Ez_tot(i0, j1) + ...
                        + ht./eps(i0, j1) .* ((Hy_tot(i0, j1) - Hy_scat(i0-1, j1))./hx - (Hx_scat(i0, j1) - Hx_tot(i0, j1-1))./hy) + ...
                        + ht./eps(i0, j0) .* (-Hy_inc_left(end) / hx - Hx_inc_top(1) / hy); 
    
    Ez_tot(i1, j0) = Ez_tot(i1, j0) + ...
                        + ht./eps(i1, j0) .* ((Hy_scat(i1, j0) - Hy_tot(i1-1, j0))./hx - (Hx_tot(i1, j0) - Hx_scat(i1, j0-1))./hy) + ...
                        + ht./eps(i1, j0) .* (Hy_inc_right(1) / hx + Hx_inc_bottom(end) / hy); 
    
    Ez_tot(i1, j1) = Ez_tot(i1, j1) + ...
                        + ht./eps(i1, j1) .* ((Hy_scat(i1, j1) - Hy_tot(i1-1, j1))./hx - (Hx_scat(i1, j1) - Hx_tot(i1, j1-1))./hy) + ...
                        + ht./eps(i1, j0) .* (Hy_inc_right(end) / hx - Hx_inc_top(end) / hy); 
    
    

    %% Update the field at the source and record field at probe

    Ez_probe(n) = Ez_tot(probe_index_x, probe_index_y); 
    
    

    
    %% Update psi_Hy_x and psi_Hx_y efficiently
    psi_Hy_x(pml_index_x, 1:P) = b_x_H(pml_index_x, 1:P) .* psi_Hy_x(pml_index_x, 1:P) + ...
                                + a_x_H(pml_index_x, 1:P) .* (Ez_scat(pml_index_x, 1:P) - Ez_scat(pml_index_x - 1, 1:P)) / hx; 
         
    psi_Hx_y(1:M, pml_index_y) = b_y_H(1:M, pml_index_y) .* psi_Hx_y(1:M, pml_index_y) + ...
                                + a_y_H(1:M, pml_index_y) .* (Ez_scat(1:M, pml_index_y) - Ez_scat(1:M, pml_index_y-1)) / hy; 
    
    %% Update Hy 
    % 
    % Scatter region: Normal update
    Hy_scat([1:(i0-2) (i1+1):(M-1)], 1:P) = Hy_scat([1:(i0-2) (i1+1):(M-1)], 1:P) + ht/mu0./hx .* (Ez_scat([2:(i0-1) (i1+2):M], 1:P) - Ez_scat([1:(i0-2) (i1+1):(M-1)], 1:P)) + ... 
                + ht/mu0 * psi_Hy_x([1:(i0-2) (i1+1):(M-1)], 1:P); 
    
    Hy_scat((i0-1):i1, [1:(j0-1) (j1+1):P]) = Hy_scat((i0-1):i1, [1:(j0-1) (j1+1):P]) + ht/mu0./hx .* (Ez_scat(i0:(i1+1), [1:(j0-1) (j1+1):P]) - Ez_scat((i0-1):i1, [1:(j0-1) (j1+1):P])) + ... 
                + ht/mu0 * psi_Hy_x((i0-1):i1, [1:(j0-1) (j1+1):P]); 
            
    %
    % Total region: Normal update without PML
    Hy_tot(i0:(i1-1), j0:j1) = Hy_tot(i0:(i1-1), j0:j1) + ht/mu0./hx .* (Ez_tot((i0+1):i1, j0:j1) - Ez_tot(i0:(i1-1), j0:j1)); 
    
    %
    % Connection between total and scatter regions  
    Hy_scat(i0-1, j0:j1) = Hy_scat(i0-1, j0:j1) + ht/mu0./hx .* (Ez_tot(i0, j0:j1) - Ez_scat(i0-1, j0:j1)) + ...
                                        - ht/mu0./hx .* Ez_inc_left; 
    
    Hy_scat(i1, j0:j1) = Hy_scat(i1, j0:j1) + ht/mu0./hx .* (Ez_scat(i1+1, j0:j1) - Ez_tot(i1, j0:j1)) + ...
                                        + ht/mu0./hx .* Ez_inc_right; 
    
 
    %% Update Hx   
    % 
    % Scatter region: Normal update
    Hx_scat([1:(i0-1) (i1+1):M], 1:P-1) = Hx_scat([1:(i0-1) (i1+1):M], 1:P-1) - ht/mu0./hy .* (Ez_scat([1:(i0-1) (i1+1):M], 2:P) - Ez_scat([1:(i0-1) (i1+1):M], 1:P-1)) + ... 
                - ht/mu0 * psi_Hx_y([1:(i0-1) (i1+1):M], 1:P-1); 
    
    Hx_scat(i0:i1, [1:(j0-2) (j1+1):P-1]) = Hx_scat(i0:i1, [1:(j0-2) (j1+1):P-1]) - ht/mu0./hy .* (Ez_scat(i0:i1, [2:(j0-1) (j1+2):P]) - Ez_scat(i0:i1, [1:(j0-2) (j1+1):P-1])) + ... 
                - ht/mu0 * psi_Hx_y(i0:i1, [1:(j0-2) (j1+1):P-1]); 
            
    %
    % Total region: Normal update without PML
    Hx_tot(i0:i1, j0:(j1-1)) = Hx_tot(i0:i1, j0:(j1-1)) - ht/mu0./hy .* (Ez_tot(i0:i1, (j0+1):j1) - Ez_tot(i0:i1, j0:(j1-1))); 
    
    
    %
    % Connection between total and scatter regions  
    Hx_scat(i0:i1, j0-1) = Hx_scat(i0:i1, j0-1) - ht/mu0./hy .* (Ez_tot(i0:i1, j0) - Ez_scat(i0:i1, j0-1)) + ...
                + ht/mu0./hy .* Ez_inc_bottom; 
            
    Hx_scat(i0:i1, j1) = Hx_scat(i0:i1, j1) - ht/mu0./hy .* (Ez_scat(i0:i1, j1+1) - Ez_tot(i0:i1, j1)) + ...
                - ht/mu0./hy .* Ez_inc_top; 
    
            
            
    %% TEST PAUSE
    Ez = Ez_tot + Ez_scat; 
    Hx = Hx_tot + Hx_scat; 
    Hy = Hy_tot + Hy_scat; 

    %% Show Ez fields every 5 frames
    if (n > 0)
            if (mod(n, 5) == 0)
                visreal(Ez, xrange, yrange); 
                title('Ez'); xlabel('x (\mum)'); ylabel('y (\mum)'); 
                pause(0.1); 
            end
    end
    
end

Ez = Ez_tot + Ez_scat; 
Hx = Hx_tot + Hx_scat; 
Hy = Hy_tot + Hy_scat; 

end

