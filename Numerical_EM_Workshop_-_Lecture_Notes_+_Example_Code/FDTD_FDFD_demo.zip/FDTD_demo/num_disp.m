function [n_num] = num_disp(L0, alpha, lambda, hw, ht)
%NUM_DISP Summary of this function goes here
%   Detailed explanation goes here

%% 
eps0 = 8.854e-12 * L0;  % vacuum permittivity in farad/L0
mu0 = pi * 4e-7 * L0;  % vacuum permeability in henry/L0
c0 = 1/sqrt(eps0*mu0);  % speed of light in vacuum in L0/sec
% ht = 1/c0 * 1/sqrt(2* (hw^-2))
% ht = 1/c0 * hw/2 

%% 
omega = 2*pi*c0/lambda; 

k_fs = 2*pi/lambda; 

k0 = 0; 
kf = 2*pi/lambda;  

hw; 

A = hw * cos(alpha) / 2; 
B = hw * sin(alpha) / 2; 
C = (hw/(c0*ht))^2 * sin(omega*ht/2)^2; 

i = 0; 
while (abs(kf - k0) > 1e-6)
    i = i+1; 
    k0 = kf; 
    kf = k0 - (sin(A*k0)^2 + sin(B*k0)^2 - C) / (A*sin(2*A*k0) + B*sin(2*B*k0)); 
end
n_num = kf / k_fs; 

end

