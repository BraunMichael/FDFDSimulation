clear all; close all; clc; 

%% Set up the domain parameters.
L0 = 1e-6;  % length unit: microns
wvlen = 1.500;  % wavelength in L0
xrange = [-2 2];  % x boundaries in L0
yrange = [-2 2];  % y boundaries in L0

hx = .0250; 
hy = .0250; 
Nsize = [round(diff(xrange) / hx)+1, round(diff(yrange) / hy)+1]; 

%% Number of PMLs. 0 layers mean PEC boundary conditions
Npml = [0 0];  % [Nx_pml Ny_pml]

%% Initialize EM constants in case we need them
eps0 = 8.854e-12 * L0;  % vacuum permittivity in farad/L0
mu0 = pi * 4e-7 * L0;  % vacuum permeability in henry/L0
c0 = 1/sqrt(eps0*mu0);  % speed of light in vacuum in L0/sec

%% Set up step size
ht = 1/c0 * 1/sqrt(hx^-2 + hy^-2) / sqrt(2); 
Tmax = 30e-15; 
N = round(Tmax / ht); 

%% Set up the relative permittivity.
eps_space = ones(Nsize);

%% Set up scatterer. Comment out if you want to simulate free space
eps_diel = 4; 
diel_loc = [0.4 1.1 0.6 1.2]; 
within_diel = @(x, y) x > diel_loc(1) & x < diel_loc(2) & y > diel_loc(3) & y < diel_loc(4); 
% eps_space = assign_val(eps_space, xrange, yrange, within_diel, eps_diel); 

%% Visualize the permittivity space
figure; 
visabs(eps_space, xrange, yrange); title('Permittivity'); 
xlabel('x (\mum)'); ylabel('y (\mum)'); 
pause

%% Setup source and probe locations
src_loc = [0, 0]; 
% src_loc = [1.7, 1.7]; 

probe_loc = [0.8, 0.8]; 

%% Apply the FDTD algorithm
tic
[Ez, Hx, Hy, Ez_probe] = FDTD(L0, wvlen, xrange, yrange, src_loc, probe_loc, N, Npml, eps_space); 

run_time = toc

%% Plotting the fields at the end of the simulation
% figure; 
% visreal(Ez, xrange, yrange); 
% title('Ez'); xlabel('x (\mum)'); ylabel('y (\mum)'); 

% Plot the field picked up by the probe
t = linspace(0, Tmax, N) * 1e15; 
figure; 
plot(t, Ez_probe); 
xlabel('t (fs)'), ylabel('Ez probe'); 


