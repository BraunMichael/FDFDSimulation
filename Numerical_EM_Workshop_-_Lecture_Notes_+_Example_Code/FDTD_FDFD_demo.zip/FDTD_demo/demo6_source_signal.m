clear all; close all; clc; 

%% Set up the domain parameters.
L0 = 1e-6;  % length unit: microns
wvlen = 1.500;  % wavelength in L0
xrange = [0 5];  % x boundaries in L0
yrange = [0 5];  % y boundaries in L0

hx = .0250; 
hy = .0250; 
Nsize = [round(diff(xrange) / hx)+1, round(diff(yrange) / hy)+1]; 

%% Number of PMLs. 0 layers mean PEC boundary conditions
Npml = [20 20];  % [Nx_pml Ny_pml]

%% Initialize EM constants in case we need them
eps0 = 8.854e-12 * L0;  % vacuum permittivity in farad/L0
mu0 = pi * 4e-7 * L0;  % vacuum permeability in henry/L0
c0 = 1/sqrt(eps0*mu0);  % speed of light in vacuum in L0/sec

%% Set up step size
ht = 1/c0 * 1/sqrt(hx^-2 + hy^-2) * 0.99; 
Tmax = 300e-15; 
N = round(Tmax / ht)

%% Set up the relative permittivity.
eps_space = ones(Nsize);

%% Set up scatterer. Comment out if you want to simulate free space
eps_wg = 12; 
wg_c = 1.01; 
wg_w = 0.151; 

within_wg = @(x, y) abs(y - wg_c) < wg_w/2; 
eps_space = assign_val(eps_space, xrange, yrange, within_wg, eps_wg); 

%% Visualize the permittivity space
figure; 
visabs(eps_space, xrange, yrange); title('Permittivity'); 
xlabel('x (\mum)'); ylabel('y (\mum)'); 
pause

%% Setup source and probe locations
src_loc = [0.8, wg_c]; 

probe_loc = [4.0, wg_c]; 

%% Apply the FDTD algorithm
tic
[Ez, Hx, Hy, Ez_probe] = FDTD_wg_src(L0, wvlen, xrange, yrange, src_loc, probe_loc, N, Npml, eps_space); 

run_time = toc

%% Plotting the fields at the end of the simulation
% figure; 
% visreal(Ez, xrange, yrange); 
% title('Ez'); xlabel('x (\mum)'); ylabel('y (\mum)'); 

% % Plot the field picked up by the probe
t = linspace(0, Tmax, N) * 1e15; 
% figure; 
% plot(t, Ez_probe); 
% xlabel('t (fs)'), ylabel('Ez probe'); 

%% 
% save ref_signal t ht Ez_probe


