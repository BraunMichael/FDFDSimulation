function [psi_w] = psi_compute(psi_pre, sigma_w, F2, F1, hw, ht)
%This function computes the next state of psi, assuming there is no
%evanescent fields
%   psi_pre is the previous state of psi at the current location 
%   sigma_w is the sigma value at the current location
%   F2 is the next half-spatial state of the field
%   F1 is the previous half-spatial state of the field
%   hw is the spatial stepsize 
%   ht is the time stepsize

if (sigma_w) == 0
    psi_w = 0; 
else
    b_w = exp(-sigma_w/8.854e-12 * ht); 
    a_w= b_w - 1; 

    psi_w = b_w * psi_pre + a_w * (F2 - F1) / hw; 
end

end

