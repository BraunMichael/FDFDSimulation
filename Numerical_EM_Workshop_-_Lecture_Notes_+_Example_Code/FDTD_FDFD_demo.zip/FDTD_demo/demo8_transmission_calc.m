clear; close all; clc; 

%% Define constants
L0 = 1e-6; 
eps0 = 8.854e-12 * L0;  % vacuum permittivity in farad/L0
mu0 = pi * 4e-7 * L0;  % vacuum permeability in henry/L0
c0 = 1/sqrt(eps0*mu0);  % speed of light in vacuum in L0/sec

%% Load transmitted signal
load probe_signal

sample_max = length(Ez_probe); 
% sample_max = floor(length(Ez_probe) / 4); 

probe = Ez_probe; 
probe = probe(1:sample_max); 
Lp = length(probe); 
time = t(1:sample_max); 

figure; 
plot(time, probe); 
xlabel('time (fs)'); ylabel('Ez probe (a.u.)'); 

% N_pad = Lp*2; 
% 
% probe = [probe, zeros(1, N_pad)]; 
% Lp = length(probe)

%% Load reference signal (0-padding if necessary)
load ref_signal

figure; plot(t, Ez_probe); 
xlabel('time (fs)'); ylabel('Ez reference (a.u.)'); 

ref = Ez_probe; 
Ls = length(ref); 

if (Ls < Lp)
    padding = zeros(1, Lp-Ls); 
    ref = [ref, padding]; 
end


%% Calculate the spectra 
[probe_freq, freq_vec] = fourierNorm(probe, ht); 
[ref_freq, ~] = fourierNorm(ref, ht); 

wvlen_vec = c0 ./ freq_vec; 



%% Calculate source and probe spectrum
figure; 
subplot(2, 1, 1); 
plot(wvlen_vec, abs(ref_freq)); 
axis([1 2 0 4]); 
xlabel('wavelength (\mum)'); ylabel('Ez reference (a.u.)'); 


subplot(2, 1, 2); 
plot(wvlen_vec, abs(probe_freq)); 
axis([1 2 0 4]); 
xlabel('wavelength (\mum)'); ylabel('Ez probe (a.u.)'); 


%% Calculate the transmission coefficient
figure; 
plot(wvlen_vec, abs(probe_freq ./ ref_freq).^2); 
axis([1.3 1.75 0 1.2]); 
xlabel('wavelength (\mum)'); ylabel('Transmission'); 


