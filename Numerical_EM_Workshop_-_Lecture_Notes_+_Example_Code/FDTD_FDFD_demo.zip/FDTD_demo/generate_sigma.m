function [sigma_array] = generate_sigma(L0, wrange, s, Nw, Nw_pml)
%UNTITLED3 Summary of this function goes here
%   xrange specifies the boundaries in x
%   yrange specifies the boundaries in y
%   eps_r specifies the relative permittivity of the simulation space
%   w specifies the coordinate direction

mu0 = 4*pi*1e-7; 
eps0 = 8.854*1e-12; 

eta0 = sqrt(mu0/eps0);  % vacuum impedance
m = 3;  % degree of polynomial grading
lnR = -12;  % R: target reflection coefficient for normal incidence

% find dw 
hw = diff(wrange) / (Nw) * L0; 
dw = Nw_pml * hw; 

% Sigma function
sig_max = -(m+1) * lnR / (2*eta0*dw);
sig_w = @(l) sig_max *(l/dw)^m; 

%% Sigma vector
% initialize sfactor_array
sigma_array = zeros(Nw, 1); 
for i = 1:Nw
    switch s
        % Forward case
        case 'f'
            if i <= Nw_pml
                sigma_array(i) = sig_w(hw * (Nw_pml - i + 0.5)); 
                
            elseif i > Nw - Nw_pml
                sigma_array(i) = sig_w(hw * (i - (Nw - Nw_pml) - 0.5)); 
            end
        % Backward case
        case 'b'
            if i <= Nw_pml
                sigma_array(i) = sig_w(hw * (Nw_pml - i + 1)); 
                
            elseif i > Nw - Nw_pml
                sigma_array(i) = sig_w(hw * (i - (Nw - Nw_pml) - 1)); 
            end
    end
end

end

