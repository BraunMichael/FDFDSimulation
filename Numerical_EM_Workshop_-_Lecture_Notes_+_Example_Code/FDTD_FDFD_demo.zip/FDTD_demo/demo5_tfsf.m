clear all; close all; clc; 

%% Set up the domain parameters.
L0 = 1e-6;  % length unit: microns
wvlen = 1.500;  % wavelength in L0
xrange = [-2.5 2.5];  % x boundaries in L0
yrange = [-2.5 2.5];  % y boundaries in L0

hx = .05; 
hy = .05; 
Nsize = [round(diff(xrange) / hx)+1, round(diff(yrange) / hy)+1]; 
% N = [60 50];  % [Nx Ny]
% N = [51 51];  % [Nx Ny]
Npml = [20 20];  % [Nx_pml Ny_pml]

%% Initialize EM constants in case we need them
eps0 = 8.854e-12 * L0;  % vacuum permittivity in farad/L0
mu0 = pi * 4e-7 * L0;  % vacuum permeability in henry/L0
c0 = 1/sqrt(eps0*mu0);  % speed of light in vacuum in L0/sec

%% Set up step size
ht = 1/c0 * 1/sqrt(hx^-2 + hy^-2) / sqrt(2); 
Tmax = 200e-15; 
N = round(Tmax / ht)

%% Set up the relative permittivity.
eps = ones(Nsize); 

%% Materials
eps_diel = 4; 

%% Assign value
diel_block = [-0.5 0.5 -0.5 0.5]; 
within_diel = @(x, y) x >= diel_block(1) & x < diel_block(2) & y > diel_block(3) & y < diel_block(4); 

% % COMMENT THIS OUT IF YOU DON'T WANT A SCATTERER
% eps = assign_val(eps, xrange, yrange, within_diel, eps_diel); 

visabs(eps, xrange, yrange); 

%% Setup source and probe locations
tfsf_loc = [-1.2 1.2 -1.5 1.5]; 
probe_loc = [1.5, 1.5]; 

%% Specify the angle
phi = 250 * pi/180; 

%% Apply the FDTD algorithm
tic
[Ez, Hx, Hy, Ez_probe] = FDTD_tfsf(L0, wvlen, xrange, yrange, tfsf_loc, phi, probe_loc, N, Npml, eps); 
% [Ez, Hx, Hy, Ez_probe] = FDTD_no_pml(L0, wvlen, xrange, yrange, src_loc, probe_loc, N, eps_air); 
run_time = toc

%% Plotting
% figure; 
% visreal(Ez, xrange, yrange); 
% figure; 
% plot(Ez_probe); 

% figure; 
% plot(log(abs(Ez_probe) ./ max(Ez_probe))); 
