function [Ez, Hx, Hy, Ez_probe] = FDTD(L0, wvlen, xrange, yrange, src_loc, probe_loc, N, Npml, eps_r)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

%% Set up numerical parameters
eps0 = 8.854e-12 * L0;  % vacuum permittivity in farad/L0
mu0 = pi * 4e-7 * L0;  % vacuum permeability in henry/L0
c0 = 1/sqrt(eps0*mu0);  % speed of light in vacuum in L0/sec

%% Compute simulation space size and step size
M = length(eps_r(:, 1))
P = length(eps_r(1, :))
Nsize = [M, P]; 

%% Initialize the computational space
x_vec = linspace(xrange(1), xrange(2), M); 
y_vec = linspace(yrange(1), yrange(2), P); 

Ez = zeros(M, P); 
Hy = zeros(M-1, P); 
Hx = zeros(M, P-1); 
Ez_probe = zeros(1, N); 

%% Initialize psi matrices
psi_Ez_x = zeros(M, P); 
psi_Ez_y = zeros(M, P); 
psi_Hx_y = zeros(M, P); 
psi_Hy_x = zeros(M, P); 

%% Create discretization steps
hx = x_vec(2) - x_vec(1); 
hy = y_vec(2) - y_vec(1); 
ht = 1/c0 * 1/sqrt(hx^-2 + hy^-2) * 0.99; 

%% Specify the location of the source
% [~, src_index_x] = min(abs(x_vec - src_loc(1))); 
% [~, src_index_y] = min(abs(y_vec - src_loc(2))); 
src_index_x = floor((src_loc(1)-xrange(1)) ./ diff(xrange) .* M) + 1
src_index_y = floor((src_loc(2:end) - yrange(1)) ./ diff(yrange) .* P) + 1

pulse_width = 1.5e-15; 
% pulse_width = 20e-15; 

%% Specify the location of the probe
probe_index_x = round((probe_loc(1)-xrange(1)) ./ diff(xrange) .* M) + 1;
probe_index_y = round((probe_loc(2)-yrange(1)) ./ diff(yrange) .* P) + 1;


%% Convert things back into meters units
hx = hx*L0; 
hy = hy*L0; 
c0 = c0*L0; 
wvlen = wvlen * L0; 

% ht = 1/c0 * 1/sqrt(hx^-2 + hy^-2); 
eps0 = eps0/L0; 
mu0 = mu0/L0; 

%% Update permittivity 
eps = eps_r * eps0; 

%% Construct sigma matrices for E
sigma_x_vec_E = generate_sigma(L0, xrange, 'f', Nsize(1), Npml(1)); 
sigma_y_vec_E = generate_sigma(L0, yrange, 'f', Nsize(2), Npml(2)); 

[sigma_x_E, sigma_y_E] = meshgrid(sigma_x_vec_E, sigma_y_vec_E); 
sigma_x_E = transpose(sigma_x_E); 
sigma_y_E = transpose(sigma_y_E); 

%% Construct sigma matrices for H
sigma_x_vec_H = generate_sigma(L0, xrange, 'f', Nsize(1), Npml(1)); 
sigma_y_vec_H = generate_sigma(L0, yrange, 'f', Nsize(2), Npml(2)); 

[sigma_x_H, sigma_y_H] = meshgrid(sigma_x_vec_H, sigma_y_vec_H); 
sigma_x_H = transpose(sigma_x_H); 
sigma_y_H = transpose(sigma_y_H); 

%% Compute indicies that are in CPML
pml_index_x = [2:Npml(1) M-Npml(2)+1:M-1]; 
pml_index_y = [2:Npml(2) P-Npml(2)+1:P-1];  

%% Compute a_x, b_x, a_y, b_y
b_x_E = exp(-sigma_x_E / eps0 * ht); 
a_x_E = b_x_E - 1; 
b_y_E = exp(-sigma_y_E / eps0 * ht); 
a_y_E = b_y_E - 1; 

b_x_H = exp(-sigma_x_H / eps0 * ht); 
a_x_H = b_x_H - 1; 
b_y_H = exp(-sigma_y_H / eps0 * ht); 
a_y_H = b_y_H - 1; 

ht./eps(2:M-1, 2:P-1)/hx; 


%% FDTD full algorithm
% % For visualization purposes
% figure('position', [200 200 1000 400]); 
% subplot(1, 3, 1); title('Ez'); xlabel('x (\mum)'); ylabel('y (\mum)'); 
% subplot(1, 3, 2); title('Hx'); xlabel('x (\mum)'); ylabel('y (\mum)'); 
% subplot(1, 3, 3); title('Hy'); xlabel('x (\mum)'); ylabel('y (\mum)'); 
% 
% pause_time = 0.001; 

for n = 1:N
    if(mod(n, 2000) == 0)
        n
    end
    
    %% Update psi_Ez_x and psi_Ez_y
    psi_Ez_x(pml_index_x, 2:P-1) = b_x_E(pml_index_x, 2:P-1).* psi_Ez_x(pml_index_x, 2:P-1) + ... 
                                    + a_x_E(pml_index_x, 2:P-1) .* (Hy(pml_index_x, 2:P-1) - Hy(pml_index_x-1, 2:P-1)) / hx; 
    psi_Ez_y(2:M-1, pml_index_y) = b_y_E(2:M-1, pml_index_y) .* psi_Ez_y(2:M-1, pml_index_y) + ...
                                    + a_y_E(2:M-1, pml_index_y) .* (Hx(2:M-1, pml_index_y) - Hx(2:M-1, pml_index_y-1)) / hy; 
    %% Compute the current source
    Jz = 1e9*exp(-(((n-1/2) * ht - 4*pulse_width)/pulse_width).^2) .* sin((2*pi*c0/wvlen) * (n-1/2)*ht); 
    
    %% Update Ez for the linear region
    Ez(2:M-1, 2:P-1) = Ez(2:M-1, 2:P-1) + ht./eps(2:M-1, 2:P-1) .* ((Hy(2:M-1, 2:P-1) - Hy(1:M-2, 2:P-1))./hx - (Hx(2:M-1, 2:P-1) - Hx(2:M-1, 1:P-2))./hy) + ...
                    + ht./eps(2:M-1, 2:P-1) .* (psi_Ez_x(2:M-1, 2:P-1) - psi_Ez_y(2:M-1, 2:P-1)); 
    
    %% Update the field at the source and record field at probe
    Ez(src_index_x, src_index_y) = Ez(src_index_x, src_index_y) - ht./eps(src_index_x, src_index_y) .* Jz; 
    Ez_probe(n) = Ez(probe_index_x, probe_index_y); 
    
        
    %% Update psi_Hy_x and psi_Hx_y efficiently
    psi_Hy_x(pml_index_x, 2:P-1) = b_x_H(pml_index_x, 2:P-1) .* psi_Hy_x(pml_index_x, 2:P-1) + ...
                                + a_x_H(pml_index_x, 2:P-1) .* (Ez(pml_index_x, 2:P-1) - Ez(pml_index_x - 1, 2:P-1)) / hx; 
         
    psi_Hx_y(2:M-1, pml_index_y) = b_y_H(2:M-1, pml_index_y) .* psi_Hx_y(2:M-1, pml_index_y) + ...
                                + a_y_H(2:M-1, pml_index_y) .* (Ez(2:M-1, pml_index_y) - Ez(2:M-1, pml_index_y-1)) / hy; 
    
    %% Update Hy 
    Hy(1:M-1, 1:P) = Hy(1:M-1, 1:P) + ht/mu0./hx .* (Ez(2:M, 1:P) - Ez(1:M-1, 1:P)) + ... 
                + ht/mu0 * psi_Hy_x(1:M-1, 1:P); 
    
    %% Update Hx   
    Hx(1:M, 1:P-1) = Hx(1:M, 1:P-1) - ht/mu0./hy .* (Ez(1:M, 2:P) - Ez(1:M, 1:P-1)) + ... 
                - ht/mu0 * psi_Hx_y(1:M, 1:P-1); 
    
    %% Visualize Ez, Hx, Hy   
    if (n > 0 & n < 700)
        if (mod(n, 10) == 0)
            visreal2(Ez, xrange, yrange, 200); 
            title('Ez'); xlabel('x (\mum)'); ylabel('y (\mum)'); 
            pause(0.1); 
        end
    end
end

end

